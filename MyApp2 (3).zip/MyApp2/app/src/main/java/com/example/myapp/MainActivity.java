package com.example.myapp;



import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText editTextTaskName, editTextDueDate;
    Button buttonAddTask;
    RecyclerView recyclerViewTasks;
    TaskAdapter taskAdapter;
    List<Task> taskList;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        editTextTaskName = findViewById(R.id.editTextTaskName);
        editTextDueDate = findViewById(R.id.editTextDueDate);
        buttonAddTask = findViewById(R.id.buttonAddTask);
        recyclerViewTasks = findViewById(R.id.recyclerViewTasks);

        // Initialize DBHelper
        dbHelper = new DBHelper(this);

        // Set up RecyclerView
        recyclerViewTasks.setLayoutManager(new LinearLayoutManager(this));

        // Load tasks from database
        loadTasks();

        // Add task button click listener
        buttonAddTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addTask();
            }
        });
        // Set onClickListener for RecyclerView items
        taskAdapter.setOnItemClickListener(new TaskAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                // Handle item click (optional)
            }

            @Override
            public void onCheckboxClick(int position) {
                taskAdapter.onCheckboxClicked(position); // Call method in TaskAdapter
            }
        });
        // Set up ItemTouchHelper for swipe-to-delete functionality
        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getAdapterPosition();
                Task taskToDelete = taskList.get(position);

                // Delete task from database and remove from list
                dbHelper.deleteTask(taskToDelete);
                taskList.remove(position);
                taskAdapter.notifyItemRemoved(position);
            }
        }).attachToRecyclerView(recyclerViewTasks);
    }

    private void loadTasks() {
        taskList = dbHelper.getAllTasks();
        taskAdapter = new TaskAdapter(this, taskList);
        recyclerViewTasks.setAdapter(taskAdapter);
    }

    private void addTask() {
        String taskName = editTextTaskName.getText().toString().trim();
        String dueDate = editTextDueDate.getText().toString().trim();

        if (!taskName.isEmpty() && !dueDate.isEmpty()) {
            Task task = new Task(taskName, dueDate, false);
            long id = dbHelper.addTask(task);

            if (id != -1) {
                task.setId((int) id);
                taskList.add(task);
                taskAdapter.notifyDataSetChanged();
                editTextTaskName.setText("");
                editTextDueDate.setText("");
            }
        }
    }
}
